import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuthStore } from "../../stores/authStore";

import logo from "../../assets/logo.png";

import "./Header.css";
import HeaderNav from "./HeaderNav";

const Header = () => {
  const { memType,memName, memNickname, signin, signOut } = useAuthStore(); // zustand 상태    memName 명하 추가
  console.log("Header memName:", memName);
  const [searchTerm, setSearchTerm] = useState(""); // 검색어
  const [result, setResult] = useState(""); // 상태 메시지

  const navigate = useNavigate();
  const location = useLocation();
  // const path = location.pathname;

  const isAuthPage = [
    "/signin",
    "/signup",
    "/corpsignin",
    "/corpsignup",
    "/findid",
    "/findpw",
  ].includes(location.pathname);
  const isCorpUser = memType === 1;

  const handleSearch = (e) => {
    if (e.key === "Enter" || e.type === "click") {
      if (searchTerm.trim() !== "") {
        // navigate(
        //   `/search?type=company&query=${encodeURIComponent(searchTerm.trim())}`
        // );//company page로 바로 이동
        navigate(`/search?query=${searchTerm.trim()}`);
      }
    }
  };

  // 개인 회원 임시 로그인
  // 개인 회원 임시 로그인
  // 개인 회원 임시 로그인
  // 개인 회원 임시 로그인
  // 개인 회원 임시 로그인
  const handleSignin = async () => {
    const { success, message } = await signin("Test_286", "Test");
    setResult(message);
  };
  // 기업 회원 임시 로그인
  // 기업 회원 임시 로그인
  // 기업 회원 임시 로그인
  // 기업 회원 임시 로그인
  // 기업 회원 임시 로그인
  const handleCorpSignin = async () => {
    const { success, message } = await signin("Test_107", "Test");
    setResult(message);
  };

  const handleSignOut = () => {
    signOut(); // zustand 초기화
    localStorage.removeItem("accessToken");

    navigate("/");
  };

  return (
    <header className="header">
      <div className="header-top">
        {/* 로고 */}
        <div className="logo">
          <Link to="/">
            <img src={logo} height="50px" alt="logo" />
          </Link>
        </div>

        {/* 검색창: 로그인/회원가입/기업회원 페이지에서는 미노출 */}
        {!isAuthPage && !isCorpUser && (
          <div className="search-box">
            <i
              className="fa-solid fa-magnifying-glass"
              onClick={handleSearch}
              style={{ cursor: "pointer" }}
            ></i>
            <input
              type="text"
              placeholder="진중한 취업이야기, 취준진담"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={handleSearch}
            />
          </div>
        )}

        {/* 사용자 정보 영역 */}
        {!isAuthPage && (
          <div className="user-info">
            {memType !== null ? (
              <>
                {memType === 1 ? (
                  <button onClick={() => navigate("/corpmypage")}>
                    {memName} 님 {/* memNickname -> memName으로 바꿈  명하 */ }
                  </button>
                ) : (
                  <button onClick={() => navigate("/mypage")}>
                    {memNickname} 님{" "}
                    {/* 기업회원은 닉네임 null인데 어떻게 할까요? */}
                  </button>
                )}
                <button onClick={handleSignOut}>로그아웃</button>
              </>
            ) : (
              <>
                <Link to="/signin">로그인</Link>
                &nbsp;|&nbsp;
                <Link to="/signup">회원가입</Link>
              </>
            )}
          </div>
        )}
      </div>

      {/* 임시 로그인 버튼 (개인/기업) */}
      <div style={{ position: "absolute", top: 0, right: 0 }}>
        <button onClick={handleSignin}>개인 로그인</button>
        <button onClick={handleCorpSignin}>기업 로그인</button>
      </div>
      {/* 네비게이션 메뉴 */}
      {!isAuthPage && <HeaderNav />}
    </header>
  );
};

export default Header;
