import React from 'react';

const NotFound = () => {
  return (
    <div className="notfound-page">
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
      <h1>NotFound_404</h1>
    </div>
  );
};

export default NotFound;
