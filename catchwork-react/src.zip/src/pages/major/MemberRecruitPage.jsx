import { Outlet } from "react-router-dom";

export default function MemberRecruitPage() {
  return (
    <div className="recruit-container">
      <Outlet />
    </div>
  );
}
