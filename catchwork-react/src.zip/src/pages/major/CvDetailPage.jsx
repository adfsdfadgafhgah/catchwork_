import React from 'react';

const SignInPage = () => {
  return (
    <div className="signin-page">
        <h1>signin</h1>
    </div>
  );
};

export default SignInPage;
