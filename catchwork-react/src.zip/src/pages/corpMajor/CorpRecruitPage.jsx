import { Outlet } from "react-router-dom";

export default function CorpRecruitPage() {
  return (
    <div className="recruit-container">
      <Outlet />
    </div>
  );
}
