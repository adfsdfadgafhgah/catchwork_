import { Outlet } from "react-router-dom";

const CorpCompanyPage = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default CorpCompanyPage;
